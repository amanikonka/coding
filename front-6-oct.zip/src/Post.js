import React from 'react'

export default function Post({ heading, para, author, title, postedOn }) {

    // fetch(`http://localhost:3001/delete-posts?Id=${Id}`)

    return (
        <div className="faq-container">
            <h1 className='heading'>{heading}</h1>
            <span className='right-top'><i class="fa fa-trash" aria-hidden="true"></i></span>
            <div>
                <span className='light-shade-color'> By </span>
                <span className='blue'> {author} </span>
                |<span className='blue'> {title} </span>|
                <span className='light-shade-color'> {postedOn}</span>
            </div>
            <p>{para}</p>
        </div>
    )
}
