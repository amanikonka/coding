import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import SquareButton from './SquareButton'

export default function Header() {

    const navigate = useNavigate()

    const logout = () => {

        localStorage.setItem('IAmAuthenticated', 'false')
        navigate('/login')

    }

    return (
        <div className='app-header'>
            <h3>Welcome to Something </h3>
            <Link to='/faq'>
                <SquareButton label='FAQ' />
            </Link>
            <Link to='/about'>
                <SquareButton label='About' />
            </Link>
            <Link to='/recipe'>
                <SquareButton label='Recipe' />
            </Link>
            <Link to='/table'>
                <SquareButton label='Table' />
            </Link>
            <Link to='/zoom'>
                <SquareButton label='Zoom' />
            </Link>
            <Link to='/cat-facts'>
                <SquareButton label='Cat Facts' />
            </Link>
            <Link to='/users'>
                <SquareButton label='Users' />
            </Link>
            <Link to='/posts'>
                <SquareButton label='Posts' />
            </Link>

            <SquareButton onClick={logout} label='Logout' />

        </div>
    )
}
