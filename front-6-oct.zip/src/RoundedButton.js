import React from 'react'

export default function RoundedButton({label}) {
  return (
    <div className='rounded'>{label}</div>
  )
}
