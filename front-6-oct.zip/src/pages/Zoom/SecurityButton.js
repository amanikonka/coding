import React from 'react'

export default function SecurityButton() {
    return (
        <div className='button-container'>
            <i class="fa fa-shield button-icon"></i>
            <div>Security</div>
        </div>
    )
}
