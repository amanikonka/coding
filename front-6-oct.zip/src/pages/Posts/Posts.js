import React, { useEffect, useState } from 'react'
import Post from '../../Post'
import { useRouteProtector } from '../../use-route-protector'

export default function Posts() {

    useRouteProtector();

    const [author, setAuthor] = useState('')
    const [heading, setHeading] = useState('')
    const [content, setContent] = useState('')


    const [posts, setPosts] = useState([])

   

    const getAllPosts = () => {
        fetch(`http://localhost:3001/get-all-posts`)
            .then(s => s.json())
            .then(response => {
                setPosts(response)
            })
    }

    const sentPost = () => {
        //send data to server

        fetch(`http://localhost:3001/create-post?author=${author}&heading=${heading}&content=${content}`)
            .then(s => s.json())
            .then(response => { 
                getAllPosts()
            })
    }

    useEffect(() => {
        //when this code will get executed?
        // only once at the component render
        getAllPosts()
    }, [])

    return (
        <div>
            <h3>Add new Post</h3>
            <div>
                <div><input placeholder='Author' value={author} onChange={e => setAuthor(e.target.value)} /></div>
                <div><input placeholder='Heading' value={heading} onChange={e => setHeading(e.target.value)} /></div>
                <div><input placeholder='Content' value={content} onChange={e => setContent(e.target.value)} /></div>
                <div><button onClick={sentPost}>Send</button></div>
                <hr />
                {posts.map(x => <Post heading={x.heading} author={x.author} para={x.content} />)}
            </div>
        </div>
    )
}
