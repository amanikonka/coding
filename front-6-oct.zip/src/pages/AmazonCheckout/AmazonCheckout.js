import React from 'react'

export default function AmazonCheckout() {
  return (
    <div>AmazonCheckout</div>
  )
}
