import { Router } from "express";
import fs from 'fs';
import { generateUUID } from '../utilities/utility.js'
const postRoutes = Router()

postRoutes.post('/posts', (req, res) => {

    //read from file to fetch prev data
    let fileContent = fs.readFileSync('./data/articles.json');

    // convert to json
    let postsList = JSON.parse(fileContent);


    let obj = {
        author: req.query.author,
        heading: req.query.heading,
        content: req.query.content,
        Id: generateUUID()
    }



    // push new item
    postsList.push(obj)

    // convert back to string
    let newFileContent = JSON.stringify(postsList)

    //write to file 

    fs.writeFileSync('./data/articles.json', newFileContent)


    res.json({})

})


postRoutes.get('/posts', (req, res) => {
    let fileContent = fs.readFileSync('./data/articles.json');
    let postsList = JSON.parse(fileContent);
    res.json(postsList)
})



postRoutes.get('/posts/:id', (req, res) => {

    let id = req.params.id

    let fileContent = fs.readFileSync('./data/articles.json');
    let data = JSON.parse(fileContent);
    
    let singleItem = data.find(x => x.Id == id)

    return res.json(singleItem)

})



postRoutes.delete('/posts', (req, res) => {

    const Id =  req.query.Id

    let fileContent = fs.readFileSync('./data/articles.json');
    let postsList = JSON.parse(fileContent);
    res.json(postsList)
})


export default postRoutes;