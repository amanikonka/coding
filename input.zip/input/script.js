function showAlertFromInput(){
    let input = document.getElementById('message-box-input')
    let message = input.value;
    alert(message)
}