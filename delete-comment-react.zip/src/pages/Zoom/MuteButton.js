import React from 'react'

export default function MuteButton() {
    return (
        <div className='button-container'>
            <i class="fa fa-microphone button-icon"></i>
            <div>Mute</div>
        </div>
    )
}
